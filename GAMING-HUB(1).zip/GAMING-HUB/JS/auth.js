const btnLogin = document.getElementById("btnLogin");
const btnRegistro = document.getElementById("btnRegistro");
const formLogin = document.getElementById("formLogin");
const formRegistro = document.getElementById("formRegistro");

function mostrarFormulario(mostrarLogin) {
    formLogin.classList.toggle("oculto", !mostrarLogin);
    formRegistro.classList.toggle("oculto", mostrarLogin);
    btnLogin.classList.toggle("activo", mostrarLogin);
    btnRegistro.classList.toggle("activo", !mostrarLogin);
}

btnLogin.addEventListener("click", () => mostrarFormulario(true));
btnRegistro.addEventListener("click", () => mostrarFormulario(false));

const contrasena = document.getElementById("contrasenaRegistro");
const repite = document.getElementById("repiteContrasena");

function comprobarContrasenas() {
    const coinciden = contrasena.value === repite.value;
    repite.setCustomValidity(coinciden ? "" : "Las contraseñas no coinciden");
}

contrasena.addEventListener("input", comprobarContrasenas);
repite.addEventListener("input", comprobarContrasenas);
